<div class="connectWrapper">
<h2>Connect With Us</h2>
<div class="connectFlex">
<div class="connectCol">
<h4>Twitch Streams</h4>
<?php include('includes/streamlist.php'); ?>
</div>
<div class="connectCol">
<h4>Twitter Feed</h4>
<a class="twitter-timeline" data-width="400" data-height="500" data-dnt="true" data-theme="dark" href="https://twitter.com/lgn_community?ref_src=twsrc%5Etfw">Tweets by lgn_community</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script> 
</div>
<div class="connectCol">
<h4>Facebook Feed</h4>
<p><i>Coming Soon</i></p>
</div>
<div class="connectCol">
<h4>LGN Discord Chanel</h4>
<p><i>Coming Soon</i></p>
</div>
</div>
</div>